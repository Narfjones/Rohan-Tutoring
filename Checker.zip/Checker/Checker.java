public interface Checker
{
// @param   String     text  is a String to consider for acceptance
// @return  boolean    true if this Checker accepts text; 
//                     false otherwise
//
  public  boolean  accept(String text);
   

}